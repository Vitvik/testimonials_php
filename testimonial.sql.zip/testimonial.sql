-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 08 2017 г., 21:20
-- Версия сервера: 10.1.26-MariaDB
-- Версия PHP: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `testimonial`
--

-- --------------------------------------------------------

--
-- Структура таблицы `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `testimonial` text NOT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `testimonials`
--

INSERT INTO `testimonials` (`id`, `id_user`, `testimonial`, `date`) VALUES
(14, 2, 'test from clas Testimonial', '2017-11-02 19:25:56'),
(21, 1, 'Lorem ipsum dolor sit amet, munere iuvaret ne duo, maiorum offendit pri ad, vim elit invidunt id.', '2017-11-28 00:00:00'),
(22, 3, 'Lorem ipsum dolor sit amet, munere iuvaret ne duo, maiorum offendit pri ad, vim elit invidunt id. Tota dolorem definitionem usu eu. Vix quodsi explicari necessitatibus ut, ad solum suscipiantur vix. Ei ius salutandi molestiae prodesset.', '2017-11-28 10:41:08'),
(23, 3, 'Lorem ipsum dolor sit amet, munere iuvaret ne duo, maiorum offendit pri ad, vim elit invidunt id. Tota dolorem definitionem usu eu.', '2017-11-28 10:41:22'),
(25, 3, 'Ð¯Ðº Ð²Ð¸ÑÐ½Ð¾Ð²Ð¾Ðº, Ð·Ð°ÑÑ‚Ð¾ÑÑƒÐ²Ð°Ð½Ð½Ñ Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼ ÐžÐžÐŸ Ð¿Ð»Ð°Ð½Ñƒ Ñ” Ð·Ñ€ÑƒÑ‡Ð½Ð¸Ð¼ Ð´Ð»Ñ Ð½Ð°Ð¿Ð¸ÑÐ°Ð½Ð½Ñ Ð²ÐµÐ»Ð¸ÐºÐ¸Ñ… Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼', '2017-11-28 10:42:57'),
(27, 1, 'ÐŸÐµÑ€ÐµÐ²Ð°Ð³Ð¸:\r\n\r\nÐ·Ð¼ÐµÐ½ÑˆÐµÐ½Ð½Ñ ÑÐºÐ»Ð°Ð´Ð½Ð¾ÑÑ‚Ñ– Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼Ð½Ð¾Ð³Ð¾ Ð·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÐµÐ½Ð½Ñ;\r\nÐ¿Ñ–Ð´Ð²Ð¸Ñ‰ÐµÐ½Ð½Ñ Ð½Ð°Ð´Ñ–Ð¹Ð½Ð¾ÑÑ‚Ñ– Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼Ð½Ð¾Ð³Ð¾ Ð·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÐµÐ½Ð½Ñ;\r\nÐ¼Ð¾Ð¶Ð»Ð¸Ð²Ñ–ÑÑ‚ÑŒ Ð¼Ð¾Ð´Ð¸Ñ„Ñ–ÐºÐ°Ñ†Ñ–Ñ— Ð¾ÐºÑ€ÐµÐ¼Ð¸Ñ… ÐºÐ¾Ð¼Ð¿Ð¾Ð½ÐµÐ½Ñ‚Ñ–Ð² Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼Ð½Ð¾Ð³Ð¾ Ð·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÐµÐ½Ð½Ñ Ð±ÐµÐ· Ð·Ð¼Ñ–Ð½Ð¸ Ñ–Ð½ÑˆÐ¸Ñ… Ð¹Ð¾Ð³Ð¾ ÐºÐ¾Ð¼Ð¿Ð¾Ð½ÐµÐ½Ñ‚Ñ–Ð²;\r\nÐ·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÐµÐ½Ð½Ñ Ð¼Ð¾Ð¶Ð»Ð¸Ð²Ð¾ÑÑ‚Ñ– Ð¿Ð¾Ð²Ñ‚Ð¾Ñ€Ð½Ð¾Ð³Ð¾ Ð²Ð¸ÐºÐ¾Ñ€Ð¸ÑÑ‚Ð°Ð½Ð½Ñ Ð¾ÐºÑ€ÐµÐ¼Ð¸Ñ… ÐºÐ¾Ð¼Ð¿Ð¾Ð½ÐµÐ½Ñ‚Ñ–Ð² Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼Ð½Ð¾Ð³Ð¾ Ð·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÐµÐ½Ð½Ñ;\r\nÐ·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÑƒÑ” ÐºÑ€Ð°Ñ‰Ñƒ Ð¼Ð¾Ð´ÑƒÐ»ÑŒÐ½Ñ–ÑÑ‚ÑŒ Ð¿Ñ€Ð¾Ð³Ñ€Ð°Ð¼Ð½Ð¾Ð³Ð¾ Ð·Ð°Ð±ÐµÐ·Ð¿ÐµÑ‡ÐµÐ½Ð½Ñ.', '2017-12-04 14:26:23');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `role` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `date`, `role`) VALUES
(1, 'admin', '123456', NULL, 1),
(2, 'vit', '123456', '2017-11-07', NULL),
(3, 'vitvik', '123456', '2017-11-07', NULL),
(4, 'testInsertNick', 'testInsertPassword', '2017-11-09', NULL),
(5, 'testInsertNick', 'testInsertPassword', '2017-11-09', NULL),
(6, 'testInsertNick2', 'testInsertPassword2', '2017-11-09', NULL),
(7, 'testInsertNick2', 'testInsertPassword2', '2017-11-09', NULL),
(8, 'testNick13', '123456', '2017-11-17', NULL),
(9, 'test_index', '123456', '2017-11-17', NULL),
(10, 'test_index', '123456', '2017-11-17', NULL),
(11, 'test_main', '123456', '2017-11-17', NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
